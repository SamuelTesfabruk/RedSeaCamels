package edu.mum.rainbow.integration.service;

public interface SampleIntegrationService {

}

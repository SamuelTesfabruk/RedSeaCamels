package edu.mum.rainbow.integration.dao;

import edu.mum.rainbow.common.model.UserCredentials;

public interface CredentialsDAO extends GenericDAO<UserCredentials> {

	public UserCredentials getByUsername(String name);
}

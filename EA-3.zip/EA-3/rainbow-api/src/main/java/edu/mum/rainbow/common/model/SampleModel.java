package edu.mum.rainbow.common.model;

public class SampleModel {

}

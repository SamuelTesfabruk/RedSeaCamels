package edu.mum.rainbow.integration.dao;

public interface SampleIntegrationDAO {

}

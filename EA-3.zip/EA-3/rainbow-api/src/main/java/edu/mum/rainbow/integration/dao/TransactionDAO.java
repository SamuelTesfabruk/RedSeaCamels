package edu.mum.rainbow.integration.dao;

import java.util.List;

import edu.mum.rainbow.common.model.Transaction;

public interface TransactionDAO extends GenericDAO<Transaction>{

	List<Transaction> fetchTransactionsByClient(String clientNo);

}

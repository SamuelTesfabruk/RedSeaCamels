package edu.mum.rainbow.integration.dao;

import edu.mum.rainbow.common.model.MonthlyStatment;

public interface MonthlyStatmentDAO extends GenericDAO<MonthlyStatment>{

}

package edu.mum.rainbow.integration.dao;

import edu.mum.rainbow.common.model.Client;

public interface ClientDAO extends GenericDAO<Client>{

}

package edu.mum.rainbow.rest.service;

import java.util.List;

import org.springframework.stereotype.Component;

import edu.mum.rainbow.common.model.Client;

@Component
public interface ClientRestService {

 	public Client save(Client client);
 	
 	public List<Client> List();
 	
}

package edu.mum.rainbow.main;

import java.util.Date;
import java.util.List;
import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Component;

import edu.mum.rainbow.common.model.Client;
import edu.mum.rainbow.common.model.Transaction;
import edu.mum.rainbow.rest.RestHttpHeader;
import edu.mum.rainbow.rest.service.ClientRestService;
import edu.mum.rainbow.rest.service.TransactionRestService;

@Component
public class RestClient {
	@Autowired
	RestHttpHeader remoteApi;

	@Autowired
	ClientRestService clientRestService;

	@Autowired
	TransactionRestService transactionRestService;

	public static void main(String[] args) {
		final ApplicationContext applicationContext = new ClassPathXmlApplicationContext("context/applicationContext.xml");

		applicationContext.getBean(RestClient.class).mainInternal(applicationContext);
	}

	@SuppressWarnings("unused")
	private void mainInternal(ApplicationContext applicationContext) {

		System.out.println("\n****************** Welcome to Rest Client ******************\n");

		Scanner sc = new Scanner(System.in);

		String[] options = { "List All Clients"  , "Create New Client", "Add Transaction", "Exit" };

		String selectedOption = null;

		System.out.print("Enter username: ");
		String username = sc.nextLine();
		System.out.print("Enter password: ");
		String password = sc.nextLine();

		do {

			System.out.println("\nSelect One of the Following Options By Index: ");

			for (int i = 0; i < options.length; i++) {
				System.out.println("\t" + i + ". " + options[i]);
			}

			System.out.print("Enter option Index: ");
			String option = sc.nextLine();
			System.out.println("");

			int index = -1;

			try {
				index = Integer.parseInt(option);
			} catch (Exception e) {
				index = -1;
			}

			if (index >= 0 && index < options.length) {
				selectedOption = options[index];
			} else {
				selectedOption = null;
				System.out.println("Invalid Option!");
			}

			if (selectedOption != null) {

				switch (selectedOption) {
				case "List All Clients":
					try {
						List<Client> clientList = clientRestService.List();
						for (int i = 0; i < clientList.size(); i++) {
							System.out.println("#"+i+ clientList.get(i));
						}
					} catch (Exception e) {
						System.out.println("Failed to list all the clients!!");
					}

					break;
					
				case "List Client Transactions (ByClientNo)":
					System.out.print("Enter ClientNo: ");
					String clientNo = sc.nextLine();
					
					try {
						List<Transaction> clientTransactions = transactionRestService.getClientTransactions(clientNo);
						for (int i = 0; i < clientTransactions.size(); i++) {
							System.out.println("#"+i+ clientTransactions.get(i));
						}
					} catch (Exception e) {
						System.out.println("Failed to list all the clients!!");
					}

					break;
					
				case "Create New Client":

					System.out.print("Enter First Name: ");
					String firstName = sc.nextLine();
					System.out.print("Enter Last Name: ");
					String lastName = sc.nextLine();
					System.out.print("Enter Client No: ");
					clientNo = sc.nextLine();
					System.out.print("Enter Email: ");
					String email = sc.nextLine();

					Client client = new Client();
					client.setFirstName(firstName);
					client.setLastName(lastName);
					client.setClientNo(clientNo);
					client.setEmail(email);
					
					try {
						clientRestService.save(client);
						System.out.println("Client Created Successfully!");
					} catch (Exception e) {
						System.out.println("Failed to Create Client!");
		        		System.out.println(e);
					}

					break;
				case "Add Transaction":
					System.out.print("Enter Transaction Id: ");
					String tranId = sc.nextLine();
					System.out.print("Enter ClientNo: ");
					String tranClientId = sc.nextLine();
					System.out.print("Enter AccountNo: ");
					String tranAccountId = sc.nextLine();
					System.out.print("Enter Description: ");
					String description = sc.nextLine();
					System.out.print("Enter Amount: ");
					String amount = sc.nextLine();
					
					Transaction tran = new Transaction();
					tran.setTranId(tranId);
					tran.setClientNo(tranClientId);
					tran.setAccountNo(tranAccountId);
					tran.setDescription(description);
					tran.setAmount(Double.parseDouble(amount));
					tran.setTranTime(new Date());
					tran.setPostingTime(new Date());

					try {
						transactionRestService.save(tran);
						System.out.println("Transaction Created Successfully!");
					} catch (Exception e) {
						System.out.println("Failed to Create Transaction!");
		        		e.printStackTrace();
					}
					break;
				}
			}

		} while (!"Exit".equalsIgnoreCase(selectedOption));

		System.out.println("\nTerminated !");
		sc.close();

	}
}

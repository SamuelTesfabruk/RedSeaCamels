package edu.mum.rainbow.business.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import edu.mum.rainbow.business.service.GroupService;
import edu.mum.rainbow.common.model.Grooups;
import edu.mum.rainbow.integration.dao.GroupDAO;

@Service
@Transactional
public class GroupServiceImpl implements GroupService {

	@Autowired
	private GroupDAO groupDAO;

	public void save(Grooups group) {
		groupDAO.save(group);
	}

	public Grooups update(Grooups group) {
		return groupDAO.update(group);
	}

	public List<Grooups> findAll() {
		return (List<Grooups>) groupDAO.findAll();
	}

}

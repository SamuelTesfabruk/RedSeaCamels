package edu.mum.rainbow.integration.dao.impl;

import java.util.List;

import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import edu.mum.rainbow.common.model.Account;
import edu.mum.rainbow.common.model.Transaction;
import edu.mum.rainbow.integration.dao.AccountDAO;
import edu.mum.rainbow.integration.dao.TransactionDAO;

@Repository
public class TransactionDAOImpl extends GenericDAOImpl<Transaction> implements TransactionDAO{

	@Autowired
	private AccountDAO accountDAO;
	
	public TransactionDAOImpl() {
		super.setDaoType(Transaction.class);
	}

	@Override
	public List<Transaction> fetchTransactionsByClient(String clientNo) {
		//Account account = accountDAO.findByClient(clientNo);
		Query query = entityManager.createQuery("select tran from Transaction tran where tran.clientNo = :clientNo and tran.accountNo = :accountNo");
		query.setParameter("clientNo", clientNo).setParameter("accountNo",12345);
		List tranList = (List<Transaction>)query.getResultList();
		return tranList;
	}
}

package edu.mum.rainbow.integration.dao.impl;

 

import org.springframework.stereotype.Repository;

import edu.mum.rainbow.common.model.Grooups;
import edu.mum.rainbow.integration.dao.GroupDAO;


@Repository
public class GroupDAOImpl extends GenericDAOImpl<Grooups> implements GroupDAO {

	public GroupDAOImpl() {
		super.setDaoType(Grooups.class );
		}

 
 }
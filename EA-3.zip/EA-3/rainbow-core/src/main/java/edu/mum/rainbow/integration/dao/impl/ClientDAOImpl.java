package edu.mum.rainbow.integration.dao.impl;

import org.springframework.stereotype.Repository;

import edu.mum.rainbow.common.model.Client;
import edu.mum.rainbow.integration.dao.ClientDAO;

@Repository
public class ClientDAOImpl extends GenericDAOImpl<Client> implements ClientDAO{

	public ClientDAOImpl() {
		super.setDaoType(Client.class);
	}
}

SET SQL_SAFE_UPDATES = 0;
delete from grooups_authority;
delete from grooups_credentials;
delete from authority;
delete from grooups;
delete from user;
delete from credentials;
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('abartoletti', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('addison.mcdermott', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('adelle67', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('ahand', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('alia50', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('aliza.fahey', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('allen.okon', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('altenwerth.layne', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('alyce.corwin', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('balistreri.lester', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('bernadine.rolfson', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('bertram40', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('bode.wyman', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('bogisich.tod', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('buford.kihn', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('carol.raynor', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('carolyne.kessler', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('chanel.haag', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('chaya.klein', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('choeger', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('cleveland.cronin', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('collier.cathrine', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('crist.candelario', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('cyril83', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('danyka11', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('della59', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('denesik.alena', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('denesik.jocelyn', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('dennis.russel', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('dickens.logan', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('dicki.aisha', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('dkeeling', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('elbert.corwin', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('elisha.koepp', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('ernestina90', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('farrell.syble', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('feil.emmy', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('fisher.alexie', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('fleffler', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('frank09', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('freichel', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('gislason.jerrell', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('giuseppe23', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('gswaniawski', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('hagenes.dangelo', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('hbechtelar', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('heathcote.willa', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('herminia.hilpert', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('hessel.mac', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('hildegard33', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('hnicolas', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('horacio.labadie', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('hoyt.smitham', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('huels.rowan', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('hwunsch', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('ihamill', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('ischuster', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('jconsidine', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('jking', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('jskiles', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('keaton59', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('kevon.hagenes', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('kirstin07', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('krystel.kulas', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('larissa.jacobson', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('lehner.urban', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('lhoppe', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('lreichert', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('mack.mayert', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('madisen69', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('marlin28', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('maurine68', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('maxie56', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('mclaughlin.gunnar', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('mhand', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('monroe.hudson', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('mschamberger', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('mueller.ludie', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('murray.esta', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('nhilll', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('nkrajcik', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('nstroman', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('okeefe.thomas', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('obalistreri', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('obie07', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('ohudson', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('onolan', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('ortiz.jacklyn', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('osbaldo.abbott', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('oswald.bergnaum', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('prohaska.brent', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('qsipes', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('ratke.beulah', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('rippin.cicero', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('runolfsdottir.abbie', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('schaefer.ezekiel', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('schinner.barbara', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('sdouglas', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('sibyl46', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('sigmund68', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('stanton.jesse', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('steuber.adrienne', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('taurean.ritchie', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('tavares.deckow', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('tremaine66', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('uzemlak', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('veda46', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('vicky.abbott', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('walter.libbie', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('ward.polly', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('wbosco', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('wbrakus', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('wendell.carter', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('westley.schowalter', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('windler.clementine', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('wiza.lolita', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('yfeest', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('zdickinson', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('zkreiger', 1, '');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('zola.klocko', 1, '');

INSERT INTO authority(authority) VALUES ('LIST'), ('CREATE'),('UPDATE'),('DELETE');

INSERT INTO authority(authority) VALUES ('CREATE_CALL');

INSERT INTO Grooups(group_name) VALUES ('ADMIN'),('CLIENT'),('USER');

INSERT INTO Grooups_Authority(Groups_id,authority_id) 
VALUES 
	((select g.id from Grooups g where g.group_name='ADMIN'),(select a.id from authority a where a.authority = 'CREATE'));

INSERT INTO Grooups_Authority(Grooups_id,authority_id) 
VALUES 
    ((select g.id from Grooups g where g.group_name='ADMIN'),(select a.id from authority a where a.authority = 'LIST')),
    ((select g.id from Grooups g where g.group_name='ADMIN'),(select a.id from authority a where a.authority = 'UPDATE')),
    ((select g.id from Grooups g where g.group_name='ADMIN'),(select a.id from authority a where a.authority = 'DELETE'))
    ;

INSERT INTO groups_authority(Grooups_id,authority_id) 
VALUES 
	((select g.id from Grooups g where g.group_name='CLIENT'),(select a.id from authority a where a.authority = 'CREATE_CALL'));

INSERT INTO Grooups_Authority(Grooups_id,authority_id) 
VALUES 
    ((select g.id from Grooups g where g.group_name='USER'),(select a.id from authority a where a.authority = 'LIST'));



INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('admin1', 1, '$2b$10$qNyyDlO7M3l66M79ZTOr..1KwGY6NwwsYXwe7nU94.tz2j9fdVoni');
INSERT INTO `credentials` (`username`, `enabled`, `password`) VALUES ('user1', 1, '$2b$10$qNyyDlO7M3l66M79ZTOr..1KwGY6NwwsYXwe7nU94.tz2j9fdVoni');


INSERT INTO user(firstName, lastName, credentialId)
VALUES
('ADMIN USER','A','admin1'),
('Regular USER','U','user1')
;


INSERT INTO Grooups_CREDENTIALS (Grooups_id, userCredentials_username)
SELECT (select g.id from Grooups g where g.group_name='CLIENT') as group_id, cd.username
FROM credentials cd
WHERE cd.username not in ('admin1','user1');

INSERT INTO Grooups_CREDENTIALS (Grooups_id, userCredentials_username)
VALUES 
((select g.id from Grooups g where g.group_name='USER'), 'user1'),
((select g.id from Grooups g where g.group_name='ADMIN'), 'admin1')
;


update credentials
set password = '$2a$10$6nNT2YTKzy/aHcnow1TWce8hO1QBDtKw.h9qrP0UsX9ILYNNMlzvq' -- password is Bill
;

update credentials
set password = '$2a$10$KNhCaE0WSKpm5Aubr0.ChOUG.YXs7nrMlb3obVoytVhkQDT.bLj9i' -- password is 12345
;


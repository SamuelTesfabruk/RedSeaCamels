

package edu.mum.rainbow.main;

import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Component;

 
@Component
public class Main {

	private final static String[] configFilesGatewayDemo = {
		"/META-INF/spring/integration/common.xml",
 		"/META-INF/spring/integration/statement-eai.xml",
		"/META-INF/spring/integration/amqp-statement-app-context.xml",
		"/META-INF/spring/integration/jms-statement-app-context.xml"
	};

 
	public static void main(String[] args) {

		//final Scanner scanner = new Scanner(System.in);

//	    RouteOrderGateway orderGateway;


		System.out.println("\n========================================================="
				+ "\n                                                         "
				+ "\n    Welcome               "
				+ "\n                                                         "
				+ "\n    For more information please visit:                   "
				+ "\n    Contact RedSea Camels Members!              "
				+ "\n                                                         "
				+ "\n=========================================================" );
 
 				System.out.println("    Loading Demo...");
				ApplicationContext applicationContext = new ClassPathXmlApplicationContext(configFilesGatewayDemo, Main.class);

			    applicationContext.getBean(Main.class).mainInternal(applicationContext);
	  }
	
	    private void mainInternal(ApplicationContext applicationContext) {
				// Wait for Messages
	    }

}

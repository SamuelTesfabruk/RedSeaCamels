package edu.mum.rainbow.main;

import java.util.Scanner;

import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

import edu.mum.rainbow.integration.publisher.StatementReportPublisher;

public class TestDirectMessageListener {

	@SuppressWarnings({ "resource" })
	public static void main(String[] args) {

		ApplicationContext context = new GenericXmlApplicationContext(
				"classpath:META-INF/spring/integration/statement-report-context.xml");

		final Scanner scanner = new Scanner(System.in);

		System.out.println("\n========================================================="
				+ "\n                                                         "
				+ "\n    Welcome to the Rainbow Reporting System!                 "
				+ "\n                                                         "
				+ "\n    For more information please visit:                   "
				+ "\n   Contact RedSea Camels team              "
				+ "\n                                                         "
				+ "\n=========================================================");

		// Used for testing BillReportListener
		RabbitTemplate directTemplate = context.getBean("directTemplate", RabbitTemplate.class);
		StatementReportPublisher directService = new StatementReportPublisher();
		directService.publish(directTemplate);

	}

}

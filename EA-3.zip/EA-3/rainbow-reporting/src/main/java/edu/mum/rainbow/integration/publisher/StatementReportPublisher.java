package edu.mum.rainbow.integration.publisher;

import org.springframework.amqp.rabbit.core.RabbitTemplate;

import edu.mum.rainbow.common.model.MonthlyStatment;

public class StatementReportPublisher {

	public void publish(RabbitTemplate rabbitTemplate) {
		MonthlyStatment statment = new MonthlyStatment();
		statment.setClientName("Samuel Tesfabruk");
		statment.setFullAccountNo("1001-9001");
		statment.setForMonth("September");
		statment.setTotalAmount(252.3);
		rabbitTemplate.convertAndSend(statment);
	}
}
